# final_proj

# NOTE
This program was designed to run online via Heroku. However, in 2022 Heroku changed their model from free to paid thus breaking this program without paying. It doesn't make sense to pay for this program for portfolio purposes, so I have made it avaiable to down if you still want to view it. You'll have to download Python and the requirements. Instruction for running locally are listed below.

For the purposes of this version, the requirement to have a '.edu' email and to confirm your email address has been removed (though you still will recieve a confirmation email). Please keep in mind some of other features may not function. Thank you! 

## Running locally

Python to run. Open in IDE (ex. Visual Studio Code) and run commands terminal.
```
pip install -r requirements.txt
python3 main.py 
```

## Google Maps API

Requires access to a Google Maps API key
```
cd final_proj
export API_KEY="API_KEY_VALUE"
```
* Replace API_KEY_VALUE, with your own key.

## Gmail

Requires access to a gmail account with 2-Factor Authentication.
```
cd final_proj
export EMAIL_APP_PASSWORD="EMAIL_APP_PASSWORD_VALUE"
```
* Replace EMAIL_APP_PASSWORD_VALUE, with your own app password from gmail.

## Heroku Link
https://seo-college-marketplace.herokuapp.com/home test
